package com.example.ppb_proyek.models;

public class ChatMessage {
    public String senderId, receiverId, message, dateTime;
}
