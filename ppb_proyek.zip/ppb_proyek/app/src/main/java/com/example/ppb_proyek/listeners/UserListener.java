package com.example.ppb_proyek.listeners;

import com.example.ppb_proyek.models.User;

public interface UserListener {
    void onUserClicked(User user);
}
